// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

#include "RcppArmadillo.h"
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;
using namespace arma;

double softt(const double& x, const double& y) {
  return arma::sign(x)*std::max(0.0,std::abs(x) - y);
}

Rcpp::List demean_sp (arma::sp_mat x) {

  //Loop over the columns
  int p = x.n_cols;
  arma::vec x_means(p,arma::fill::zeros);
  int count = 0;
  for(int i=0;i<p;i++){
    count++;
    arma::sp_mat x_i = x.col(i);
    sp_mat::iterator it;
    sp_mat::iterator it_end = x_i.end();
    
    double col_sum = 0;
    double counter = 0;
    
    //Obtain column mean
    for(it = x_i.begin(); it != it_end; ++it){
      
      counter = counter + 1;
      col_sum = col_sum + *it;
    }
    double mean_i = col_sum/counter;
    x_means(i) = mean_i;
    
    //Demean non-zero elements
    for(it = x_i.begin(); it != it_end; ++it){
      *it = *it - mean_i;
    }
    x.col(i) = x_i;
  }
  
  //Provide de-meaned matrix and column means as output
  Rcpp::List ret = Rcpp::List::create(Named("x") = x , _["colmeans"] = x_means);
  return ret;
}

Rcpp::List scale_sp (const arma::sp_mat& x,const bool center = true, const bool standardise = true) {
  
  //Loop over the columns
  int p = x.n_cols; int n = x.n_rows;
  int count = 0;
  
  arma::sp_mat x_sd(n,p); //Store standardized matrix (still faster because of call by reference)
  arma::vec colmeans(p), colsds(p);
  if(!center && !standardise){
    x_sd = x;
  }else{
    for(int i=0;i<p;i++){
      count++;
      arma::sp_mat x_i(x.col(i));
      
      double col_sum = 0;
      double col_sum_sq = 0;
      
      int counter = 0;
      
      //Obtain column means and sds
      for(sp_mat::iterator it = x_i.begin(); it != x_i.end(); ++it){
        counter++;
        col_sum += *it;
        col_sum_sq += pow(*it,2);
      }
      
      //Store mean
      double mean_i;
      if(center){
        mean_i = col_sum/counter;
        colmeans(i) = mean_i;
      }else{
        mean_i = 0;
      }
      
      //store standard deviation
      double sd_i;
      if(standardise){
        sd_i = sqrt((col_sum_sq - pow(col_sum,2)/counter)/(n-1));
        colsds(i) = sd_i;
      }else{
        sd_i = 1;
      }
      
      //Standardise non-zero elements
      for(sp_mat::iterator it = x_i.begin(); it != x_i.end(); ++it){
        *it = (*it - mean_i)/sd_i;
      }
      x_sd.col(i) = x_i;
    }
  }
  
  
  //Provide de-meaned matrix and column means as output
  Rcpp::List output = Rcpp::List::create(Named("x_sd") = x_sd, _["colmeans"] = colmeans, _["colsds"] = colsds);
  return output;
}

Rcpp::List scale_dense (arma::mat x,const bool center = true, const bool standardise = true) {

  //Loop over the columns
  int p = x.n_cols; int n = x.n_rows;
  arma::vec colmeans(p), colsds(p);

  if(center || standardise){
    int count = 0;
    for(int i=0;i<p;i++){
      count++;
      arma::vec x_i(x.col(i));
      double mean_i, sd_i;

      //Store means
      if(center){
        mean_i = arma::mean(x_i);
        colmeans(i) = mean_i;
      }else{
        mean_i = 0;
      }
      
      //Store sds
      if(standardise){
        sd_i = arma::stddev(x_i);
        colsds(i) = sd_i;
      }else{
        sd_i = 1;
      }
      
      //Normalise data
      for(int j=0; j<n; j++){
        x(j,i) = (x(j,i)-mean_i)/sd_i;
      }
    }
  }
  
  //Provide de-meaned matrix and column means as output
  Rcpp::List output = Rcpp::List::create(Named("x_sd") = x, _["colmeans"] = colmeans, _["colsds"] = colsds);
  return output;
}

arma::sp_mat pow_sp (const arma::sp_mat& x, const double& power) {
  
  arma::sp_mat x_pow = x;
  for(sp_mat::iterator it = x_pow.begin(); it != x_pow.end(); ++it) {
    *it = pow(*it,power);
  }
  return x_pow;
}

arma::sp_mat col_sp(const arma::sp_mat& x,const arma::uvec& index) {
  int n_cols = index.n_elem;
  arma::sp_mat x_subset(x.n_rows,index.n_elem);
  for(int i=0; i<n_cols; i++){
    x_subset.col(i) = x.col(index(i));
  }
  return x_subset;
}

arma::sp_mat col_remove_sp(arma::sp_mat x,arma::uvec index){
  index = sort(index,"descend");
  for(unsigned int i=0; i<index.n_elem; i++){
    unsigned int col_index = index(i);
    x.shed_col(col_index);
  }
  return x;
}

arma::sp_mat submat_sp(const arma::sp_mat& x,const arma::uvec& index_rows,const arma::uvec& index_cols) {
  int n_rows = index_rows.n_elem; int n_cols = index_cols.n_elem;
  arma::sp_mat x_subset(n_rows,n_cols);
  for(int i=0; i<n_rows; i++){
    for(int j=0; j<n_cols; j++){
      x_subset(i,j) = x(index_rows(i),index_cols(j));
    }
  }
  return x_subset;
}

arma::sp_mat block_diagonal(const arma::mat& x,const int& n_blocks){
  int n_rows = x.n_rows; int n_cols = x.n_cols;
  arma::sp_mat x_blocked(n_blocks*n_rows,n_blocks*n_cols);

  //Fill sparse matrix with diagonal blocks
  for(int i=0; i<n_blocks; i++){
    x_blocked(arma::span(i*n_rows,(i+1)*n_rows-1),arma::span(i*n_cols,(i+1)*n_cols-1)) = x;
  }
  return x_blocked;
}

arma::uvec match_in(const arma::vec& x, const arma::vec& y){
  int n_y = y.n_elem;
  arma::uvec matches, match_i;
  for(int i=0; i<n_y; i++){
    match_i = find(x == y(i));
    matches = join_cols(matches,match_i);
  }
  matches = arma::unique(matches);
  return matches;
}

int bandwidth_bootstrap(const arma::mat& x,const arma::mat& y,const int B = 1000){
  
  int t = x.n_rows, ty = y.n_rows, n = x.n_cols, ny = y.n_cols;
  if(ty != t || ny != n){
    Rcpp::stop("Dimensions of x and y do not match");
  }
  arma::mat sigma_hat = x.t()*y/t;
  arma::vec errors_total(n,arma::fill::zeros);
  arma::vec errors_b(n,arma::fill::zeros);
  int b = 0;
  while(b<B){
    b++;
    arma::vec u = arma::randn(t) + 1;
    arma::mat sigma_b = x.t()*arma::diagmat(u)*y/t;
    errors_b(n-1) = arma::norm(sigma_b-sigma_hat,1);
    for(int i = n-1; i>0; i--){
      for(int j = 0; j < (n-i); j++){
        sigma_b(i+j,j) = 0; //Set lower diagonals equal to zero
        sigma_b(j,i+j) = 0; //Set upper diagonals equal to zero
      }
      errors_b(i-1) = arma::norm(sigma_b-sigma_hat,1);
    }
    errors_total = errors_total + errors_b;
  }
  int k = errors_total.index_min();
  return k;
}

arma::vec splash_lambdas (const arma::mat& Y,const arma::vec& group_labels,const arma::vec& alphas,
                          arma::vec lambdas, const int n_lambdas, arma::uvec ind_x_rem,
                          const bool center, const bool standardise,
                          const double lambda_min_mult) {
  
  //Obtain covariances
  int nobs = Y.n_rows;
  arma::mat Y_lead = Y.rows(1,nobs-1);
  arma::mat Y_lag = Y.rows(0,nobs-2);
  arma::mat Sigma1hatT = Y_lag.t()*Y_lead/nobs;
  arma::mat Sigma0hat = Y_lag.t()*Y_lag/nobs;
  arma::mat X = join_rows(Sigma1hatT,Sigma0hat);
  
  //vectorise and standardise y
  arma::vec y = arma::vectorise(Sigma1hatT);
  int t = y.n_rows;
  
  //Normalise y
  double y_mean=0, y_sd=1;
  if(center || standardise){
    double y_sum = as_scalar(sum(y));
    if(center){
      y_mean = y_sum/t;
    }
    if(standardise){
      double y_sum_squared = as_scalar(sum(pow(y,2)));
      y_sd = sqrt((y_sum_squared - pow(y_sum,2)/t)/(t-1));
      //y_sd = as_scalar(sqrt(sum(pow(y,2))));
    }
    y = (y-y_mean)/y_sd;
  }
  
  //standardize x and turn into sparse block-diagonal matrix
  int n_x_cols = X.n_cols; int n_x_rows = X.n_rows;
  arma::rowvec x_means(n_x_cols,arma::fill::zeros), x_sds(n_x_cols,arma::fill::ones);
  if(center || standardise){
    arma::rowvec x_sums = sum(X);
    if(center){
      x_means = x_sums/n_x_rows;
    }
    if(standardise){
      arma::rowvec x_sums_squared = sum(pow(X,2));
      x_sds = sqrt((x_sums_squared - pow(x_sums,2)/n_x_rows)/(t-1));
      //x_sds = sqrt(x_sums_squared);
    }
    for(int i=0; i<n_x_cols; i++){
      X.col(i) = (X.col(i)-x_means(i))/x_sds(i);
    }
  }
  arma::sp_mat x = block_diagonal(X,n_x_rows);
  
  //Extend vector of means and sds
  int n_full = n_x_cols*n_x_rows;
  arma::rowvec x_means_full(n_full), x_sds_full(n_full);
  for(int i=0; i<n_x_rows; i++){
    x_means_full(span(i*n_x_cols,(i+1)*n_x_cols-1)) = x_means;
    x_sds_full(span(i*n_x_cols,(i+1)*n_x_cols-1)) = x_sds;
  }
  
  //Remove columns/elements corresponding to diagonal coefficients
  ind_x_rem = sort(ind_x_rem-1,"descend");
  for(unsigned int i=0; i<ind_x_rem.n_elem; i++){
    unsigned int col_index = ind_x_rem(i);
    x.shed_col(col_index);
    x_means_full.shed_col(col_index);
    x_sds_full.shed_col(col_index);
  }
  
  //Define useful quantities
  arma::vec xy = x.t()*y;
  
  //Define group labels and max penalty (differs depending on alphas)
  arma::vec labels_unique, group_sizes, list_order;
  Rcpp::List indices_groups;
  double lambda_max;
  int n_labels = 0;
  if(alphas.n_elem==1 && (alphas(0)==0 || alphas(0)==1)){
    
    //Pure group lasso
    if(alphas(0)==0){
      
      //Define groups and individual coefficients
      labels_unique = unique(group_labels);
      n_labels = labels_unique.n_elem;
      indices_groups = Rcpp::List(n_labels);
      group_sizes = arma::vec(n_labels,arma::fill::zeros);
      for(int i=0; i<n_labels; i++){
        arma::uvec group_matches = find(group_labels==labels_unique(i));
        indices_groups[i] = group_matches;
        group_sizes(i) = group_matches.n_elem;
      }
      list_order = arma::linspace(0,n_labels-1,n_labels);
      list_order = list_order(arma::sort_index(group_sizes,"descend")); //To treat the largest groups first
      
      if(lambdas(0)== -1){
        //Define grid of penalties
        Rcpp::List xy_crossprods(n_labels);
        arma::vec xy_norms(n_labels,arma::fill::zeros);
        arma::sp_mat x_g;
        arma::vec xy_g;
        for(int i=0; i<n_labels; i++){
          arma::uvec ind_group_i = indices_groups[i];
          x_g = col_sp(x,ind_group_i);
          xy_g = xy(ind_group_i)/t;
          xy_crossprods[i] = xy_g;
          xy_norms(i) = norm(xy_g,2)/sqrt(x_g.n_cols);
        }
        lambda_max = max(xy_norms); //maximum group penalty
        double lambda_min = lambda_min_mult*lambda_max;
        lambdas = exp(arma::linspace(log(lambda_max),log(lambda_min),n_lambdas));
      }
      
      //Pure lasso
    }else{
      if(lambdas(0)==-1){
        lambda_max = max(abs(xy))/t;
        double lambda_min = lambda_min_mult*lambda_max;
        lambdas = exp(arma::linspace(log(lambda_max),log(lambda_min),n_lambdas));
      }
    }
    
    //Sparse Group Lasso settings
  }else{
    //Define groups and individual coefficients
    labels_unique = unique(group_labels);
    n_labels = labels_unique.n_elem;
    indices_groups = Rcpp::List(n_labels);
    group_sizes = arma::vec(n_labels,arma::fill::zeros);
    for(int i=0; i<n_labels; i++){
      arma::uvec group_matches = find(group_labels==labels_unique(i));
      indices_groups[i] = group_matches;
      group_sizes(i) = group_matches.n_elem;
    }
    list_order = arma::linspace(0,n_labels-1,n_labels);
    list_order = list_order(arma::sort_index(group_sizes,"descend")); //To treat the largest groups first
    
    if(lambdas(0) == -1){
      //Define grid of penalties
      Rcpp::List xy_crossprods(n_labels);
      arma::vec xy_norms(n_labels,arma::fill::zeros);
      arma::sp_mat x_g;
      arma::vec xy_g;
      double xy_g_max = 0, lambda_imax = 0;
      for(int i=0; i<n_labels; i++){
        arma::uvec ind_group_i = indices_groups[i];
        x_g = col_sp(x,ind_group_i);
        xy_g = xy(ind_group_i)/t;
        xy_g_max = max(abs(xy_g));
        xy_crossprods[i] = xy_g;
        xy_norms(i) = norm(xy_g,2)/sqrt(x_g.n_cols);
        if(xy_g_max > lambda_imax){
          lambda_imax = xy_g_max;
        }
      }
      double lambda_gmax = max(xy_norms); //maximum group penalty
      lambda_max = std::max(lambda_gmax,lambda_imax);
      double lambda_min = lambda_min_mult*lambda_max;
      lambdas = exp(arma::linspace(log(lambda_max),log(lambda_min),n_lambdas));
    }
  }
  
  //Collect output in list
  return lambdas;
}

// [[Rcpp::export(.splash_rcpp)]]
Rcpp::List splash_rcpp (const arma::mat& Y,const arma::cube& X, const arma::vec& alphas,arma::vec lambdas,
                        const int n_lambdas,const bool& banded_coefs,arma::vec banded_covs,
                        const int& B, const bool& standardise,const bool& symmetric_diags,
                        const bool track_progress,const double& thresh,
                        const int& max_steps,const double& lambda_min_mult) {
  
  //Obtain covariances
  int t = Y.n_rows, n = Y.n_cols, n2 = 2*n, n_sq = pow(n,2);
  arma::mat Y_lead = Y.rows(1,t-1);
  arma::mat Y_lag = Y.rows(0,t-2);
  arma::mat Sigma1hatT = Y_lag.t()*Y_lead/t;
  arma::mat Sigma0hat = Y_lag.t()*Y_lag/t;
  
  //Band covariance matrices if desired
  bool banding = arma::any(banded_covs != 0);
  if(banding){
    
    int k0 = banded_covs(0);
    if(k0 != 0){
      if(k0 == -1){
        k0 = bandwidth_bootstrap(Y_lag,Y_lag,B);
        banded_covs(0) = k0;
      }
      //Band Sigma0hat
      if(k0 < n-1){
        for(int i = n-1; i>k0; i--){
          for(int j = 0; j < (n-i); j++){
            Sigma0hat(i+j,j) = 0; //Set lower k diagonals equal to zero
            Sigma0hat(j,i+j) = 0; //Set upper k diagonals equal to zero
          }
        }
      }
    }
    
    //Band Sigma1hatT
    int k1 = banded_covs(1);
    if(k1 != 0){
      if(k1 == -1){
        k1 = bandwidth_bootstrap(Y_lead,Y_lag,B);
        banded_covs(1) = k1;
      }
      if(k1 < n-1){
        for(int i = n-1; i>k1; i--){
          for(int j = 0; j < (n-i); j++){
            Sigma1hatT(i+j,j) = 0; //Set lower k diagonals equal to zero
            Sigma1hatT(j,i+j) = 0; //Set upper k diagonals equal to zero
          }
        }
      }
    }
  }
  arma::mat V = join_rows(Sigma1hatT,Sigma0hat);
  
  //Obtain covariances with exogenous regressors
  int k_x=0;
  if(X.n_elem != 1 || X(0,0,0) != -1){
    k_x = X.n_slices;
    arma::mat Sigma0XY(k_x*n,n,fill::zeros);
    arma::mat Sigma1XY(k_x*n,n,fill::zeros);
    arma::mat Sigma0XX(k_x*n,k_x*n,fill::zeros);
    for(int i=0; i<k_x; i++){
      arma::mat X_i = X.slice(i).rows(1,t-1);
      Sigma0XY.rows(i*n,(i+1)*n-1) = X_i.t()*Y_lead/t;
      Sigma1XY.rows(i*n,(i+1)*n-1) = X_i.t()*Y_lag/t;
      for(int j=0; j<k_x; j++){
        Sigma0XX.submat(i*n,j*n,(i+1)*n-1,(j+1)*n-1) = X_i.t()*X.slice(j).rows(1,t-1)/t;
      }
    }
    V = join_rows(V,Sigma1XY.t());
    V = join_cols(V,join_rows(Sigma0XY,Sigma1XY,Sigma0XX)); //Adjusted V with exo-regs
    Sigma1hatT = join_cols(Sigma1hatT,Sigma0XY); //Adjusted Sigma1hatT with exo-regs
  }
  int n_v = V.n_cols, n_total = (2+k_x)*n_sq, n_y = (1+k_x)*n_sq;
  
  //Obtain group labels
  arma::mat A_labels = arma::zeros<mat>(n,n);
  for(int i=0; i<n; i++){
    A_labels.row(i) = arma::regspace(n,n2-1).t() - i; //Fill diagonals row-wise
  }
  
  if(banded_coefs){
    int lower_cutoff = std::ceil(n-n/4);
    int upper_cutoff = std::floor(n+n/4);
    A_labels.elem(arma::find(A_labels <= lower_cutoff || A_labels >= upper_cutoff)).zeros();
  }
  
  if(symmetric_diags){
    A_labels = symmatl(A_labels); //Reflect the upper triangle to the lower
  }
  
  //Create AB labels matrix
  arma::mat B_labels = A_labels;
  B_labels.elem(find(B_labels > 0)) = B_labels.elem(find(B_labels > 0)) + n2; //Make sure that groups do not overlap
  A_labels.diag().zeros(); //Set diagonal to zero
  arma::mat AB_labels = join_rows(A_labels,B_labels).t();
  
  //Add labels for exogenous regressors
  unsigned int max_group = AB_labels.max();
  if(X.n_elem != 1 || X(0,0,0) != -1){
    arma::mat E(n,k_x*n,fill::zeros);
    int label_i;
    for(int i=0; i<k_x; i++){
      label_i = max_group + 1 + i;
      for(int j=0; j<n; j++){
        E(j,i*n+j) = label_i; //A wide matrix with constant diagonal sub-matrices
      }
    }
    AB_labels = join_cols(AB_labels,E.t());
  }
  
  //Define vectorised group labels
  arma::vec group_labels_all = vectorise(AB_labels); //vectorize the coefficients
  int n_all = group_labels_all.n_elem;
  arma::uvec ind_x_rem = find(group_labels_all == 0);
  arma::uvec ind_x_incl = find(group_labels_all);
  arma::vec group_labels = group_labels_all.elem(ind_x_incl);
  arma::vec groups_unique = unique(group_labels);
  
  //Obtain index sampling for rows and columns of V'V
  arma::uvec gr = ones<uvec>(n_total), gc = ones<uvec>(n_total);
  for(unsigned int i=0; i < (unsigned int)n; i++){
    gr.subvec(i*n_v,(i+1)*n_v-1) = regspace<uvec>(0,n_v-1); //Used to sample rows
    gc.subvec(i*n_v,(i+1)*n_v-1).fill(i); //Used to sample columns
  }
  
  //Obtain indices for sampling cross-products of groups
  arma::umat col_ind = reshape(regspace<uvec>(0,n_total - 1),n_v,n); //Index for vectorized chunks of SigmaonehatT and c
  
  arma::uvec range_i;
  Rcpp::List I_C(n_all), I_G(n_all), I_ind(n_all); //I_C samples columns for V_g'V_{-g} and I_G for V_g'V_g
  if(!(all(alphas==1))){
    //Indices required for (sparse) group lasso
    arma::vec group_c_i;
    for(int i=0; i<n_all; i++){
      int group_i = group_labels_all(i);
      if(group_i != 0){
        range_i = col_ind.col(floor(i/(n_v)));
        group_c_i = groups_unique(find(groups_unique!=group_i));
        I_C[i] = match_in(group_labels_all(range_i),group_c_i) + min(range_i);
        I_G[i] = find(group_labels_all(range_i)==group_i) + min(range_i);
      }
    }
  }
  
  if(!(all(alphas<1))){
    //Indices required if a pure lasso is performed
    arma::uvec ind_i;
    for(unsigned int i : ind_x_incl){
      range_i = col_ind.col(floor(i/(n_v)));
      ind_i = find(group_labels_all(range_i) != 0) + min(range_i);
      ind_i = ind_i(find(ind_i != i));
      I_ind[i] = ind_i;
    }
  }
  
  //Obtain group indices and sizes
  int n_groups = groups_unique.n_elem;
  Rcpp::List group_indices(n_groups), group_partitions(n_groups);
  arma::vec group_sizes = ones(n_groups);
  arma::uvec group_i;
  for(int i=0; i<n_groups; i++){
    group_i = find(group_labels_all == groups_unique(i));
    group_indices[i] = group_i;
    group_sizes(i) = group_i.n_elem;
    
    //Create lists for within-group partitions
    Rcpp::List group_i_partition(n);
    arma::vec group_i_vec = conv_to<arma::vec>::from(group_i);
    for(int j=0; j<n; j++){
      arma::vec range_j = conv_to<arma::vec>::from(col_ind.col(j));
      arma::uvec group_i_range_j = group_i.elem(match_in(group_i_vec,range_j));
      group_i_partition[j] = group_i_range_j;
    }
    group_partitions[i] = group_i_partition;
  }
  
  //Standardisation
  arma::mat Sigma1hatV;
  double SS;
  arma::vec sds = ones(n_v);
  double sd_y=1;
  if(standardise==true){
    for(int i=0; i<n_v; i++){
      sds(i) = sqrt(sum(square(V.col(i)-sum(V.col(i))/n))/(n_y-1));
      V.col(i) = V.col(i)/sds(i);
    }
    double mean_y = accu(Sigma1hatT)/n_y;
    sd_y = sqrt(accu(square(Sigma1hatT-mean_y))/(n_y-1));
    Sigma1hatV = Sigma1hatT.t()*V/sd_y;
    SS = accu(pow(Sigma1hatT,2))/pow(sd_y,2);
  }else{
    Sigma1hatV = Sigma1hatT.t()*V;
    SS = accu(pow(Sigma1hatT,2));
  }
  arma::mat VV = V.t()*V;
  
  //Generate penalties if not user provided
  double lambda_max=0;
  int n_alphas = alphas.n_elem, n_penalties = lambdas.n_elem*n_alphas;
  if(lambdas.n_elem==1 && lambdas(0)==-1){
    
    if(n_alphas==1 && alphas(0)==0){
      //penalties for pure group lasso
      
      arma::vec Vy_g_norms = ones(n_groups);
      for(int i=0; i<n_groups; i++){
        
        //Calculate the norm and absolute maximum of V^d_g'y/t
        arma::vec Vy_g = zeros(group_sizes(i));
        for(int j=0; j<group_sizes(i); j++){
          arma::uvec group_i = group_indices[i];
          unsigned int g_j = group_i(j);
          Vy_g(j) = Sigma1hatV(gc(g_j),gr(g_j))/n_y;
        }
        Vy_g_norms(i) = sqrt(sum(square(Vy_g)))/sqrt(group_sizes(i));
      }
      lambda_max = max(Vy_g_norms); //maximum group penalty
      
    }else if(n_alphas==1 && alphas(0) == 1){
      
      //Penalties for pure lasso
      arma::vec Vy_abs = zeros(group_labels.n_elem);
      int iter = -1;
      for(int i=0; i<n_groups; i++){
        for(int j=0; j<group_sizes(i); j++){
          iter++;
          arma::uvec group_i = group_indices[i];
          unsigned int g_j = group_i(j);
          Vy_abs(iter) = abs(Sigma1hatV(gc(g_j),gr(g_j)));
        }
      }
      lambda_max = arma::max(Vy_abs)/n_y;
      
    }else{
      //Penalties for sparse group lasso
      
      arma::vec Vy_g_norms = zeros(n_groups);
      arma::vec Vy_abs = zeros(group_labels.n_elem);
      int iter = -1;
      
      for(int i=0; i<n_groups; i++){
        
        //Calculate the norm and absolute maximum of V^d_g'y/t
        arma::vec Vy_g = zeros(group_sizes(i));
        for(int j=0; j<group_sizes(i); j++){
          iter++;
          arma::uvec group_i = group_indices[i];
          unsigned int g_j = group_i(j);
          Vy_abs(iter) = abs(Sigma1hatV(gc(g_j),gr(g_j)));
          Vy_g(j) = Sigma1hatV(gc(g_j),gr(g_j))/n_y;
        }
        Vy_g_norms(i) = sqrt(sum(square(Vy_g)))/sqrt(group_sizes(i));
      }
      double lambda_i_max = arma::max(Vy_abs)/n_y; //maximum individual penalty
      double lambda_g_max = arma::max(Vy_g_norms); //maximum group penalty
      lambda_max = std::max(lambda_i_max,lambda_g_max); //maximum sgl penalty
    }
    double lambda_min = lambda_min_mult*lambda_max;
    lambdas = exp(linspace(log(lambda_max),log(lambda_min),n_lambdas));
    n_penalties = n_lambdas*n_alphas;
  }
  arma::vec group_seq = regspace(0,n_groups-1);//
  group_seq = group_seq(arma::sort_index(group_sizes,"descend")); //To treat the largest groups first
  
  //Initialize coefficients
  arma::mat c_all = mat(n_total,n_penalties,fill::zeros); //initialize matrix with all solutions
  
  if(track_progress==true){
    Rcout << "Pre-work done. Start of the algorithm..." << std::endl;
  }
  
  //Loop over alphas
  int lambda_counter = 0;
  for(int i=0; i<n_alphas; i++){
    Rcpp::checkUserInterrupt();
    
    double c_loss = SS/n_total;
    double alpha = alphas(i);
    arma::vec c = zeros(n_total); //reset warm start for c
    
    //Compute group lasso
    if(alpha == 0){
      
      //Loop over penalties
      arma::vec c_old;
      for(int j=0; j<n_lambdas; j++){
        lambda_counter++;
        
        double lambda_j = lambdas(j);
        
        //Iterate over the full vector c
        bool c_test = true;
        int c_counter = 0;
        //int c_g_print = 0;
        while(c_test==true && c_counter < max_steps){
          Rcpp::checkUserInterrupt();
          
          c_counter++;
          c_old = c;
          
          //Loop over groups in c
          for(unsigned int g : group_seq){
            Rcpp::checkUserInterrupt();
            
            //Define group and coefficients
            arma::uvec index_g = group_indices[g]; //Indices of group g
            int n_g = group_sizes(g); //size of group g
            unsigned int group_g = groups_unique(g);
            
            //Define V_g^d'r_{-g}
            arma::vec Vr_g = zeros(n_g);
            for(int l=0; l<n_g; l++){
              arma::uvec ind_c = I_C[index_g(l)];
              arma::uvec c_cols_l = gr(ind_c);
              arma::uvec c_row_l(1); c_row_l.fill(gr(index_g(l)));
              Vr_g(l) = Sigma1hatV(gc(index_g(l)),gr(index_g(l))) -
                as_scalar(VV(c_row_l,c_cols_l)*c(ind_c));
            }
            
            //Define r_g'r_g/(2n^2)
            double cVVc_g = 0;
            for(int m=0; m<n; m++){
              arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
              cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
            }
            double rr_g = c_loss + (2*as_scalar(Vr_g.t()*c(index_g)) - cVVc_g)/n_total;
            
            //Check criteria for non-zero group
            if(group_g > max_group){
              
              //Estimate coefficients of exogenous regressors with L1 penalty only
              
              //Inner Loop
              bool c_g_test = true;
              int c_g_counter = 0;
              //arma::vec U_l_old = c(index_g), c_g_old, U_l; //Warm start for c_g
              arma::vec U_l_old = arma::zeros(n_g), c_g_old;
              arma::vec U_l = zeros(n_g);
              int step_counter;
              while(c_g_test==true &&  (c_g_counter < max_steps)){
                Rcpp::checkUserInterrupt();
                c_g_counter++;
                c_g_old = c(index_g);
                
                //Define the gradient for group g
                arma::vec grad_min_g = -Vr_g;
                for(int l=0; l<n_g; l++){
                  //Add -V_g^d'(-V_g^d c_g) and divide by t
                  arma::uvec ind_g = I_G[index_g(l)];
                  arma::uvec g_cols_l = gr(ind_g);
                  arma::uvec g_row_l(1); g_row_l.fill(gr(index_g(l)));
                  grad_min_g(l) = (grad_min_g(l) +
                    as_scalar(VV(g_row_l,g_cols_l)*c(ind_g)))/n_y;
                }
                
                //Nesterov updates
                bool step_test = true;
                double v = 1/0.8;
                step_counter = 0;
                while(step_test == true && step_counter < max_steps){
                  step_counter++;
                  v = 0.8*v;
                  for(int k=0; k<n_g; k++){
                    U_l(k) = softt(c_g_old(k)-v*grad_min_g(k),v*lambda_j);
                  }
                  arma::vec delta_l = U_l - c_g_old;
                  c(index_g) = U_l;
                  
                  //Compute the value of the interim squared loss function
                  cVVc_g = 0;
                  for(int m=0; m<n; m++){
                    arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
                    cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                      VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
                  }
                  double U_loss = rr_g  + (cVVc_g - 2*as_scalar(Vr_g.t()*c(index_g)))/n_total;
                  
                  step_test = U_loss > c_loss + as_scalar(grad_min_g.t()*delta_l)
                    + sum(square(delta_l))/(2*v);
                }
                
                //Update coefficients
                c(index_g) = U_l_old + (U_l-U_l_old)*(c_g_counter/(c_g_counter+3));
                U_l_old = U_l;
                
                //Compute the new value of the squared loss function
                cVVc_g = 0;
                for(int m=0; m<n; m++){
                  arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
                  cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                    VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
                }
                c_loss = rr_g  + (cVVc_g - 2*as_scalar(Vr_g.t()*c(index_g)))/n_total;
                
                //Check for convergence
                if(c_g_counter == 1){
                  c_g_test = true;
                }else if(all(c_g_old==0)){
                  c_g_test = false;
                }else{
                  double c_g_old_norm = sqrt(sum(square(c_g_old)));
                  double c_g_diff = sqrt(sum(square(c(index_g)-c_g_old)))/c_g_old_norm;
                  c_g_test = c_g_diff > thresh;
                }
              } //closes while-loop for c_g
              
            }else if(sqrt(sum(square(Vr_g)))/n_y <= sqrt(n_g)*lambda_j){
              c(index_g).fill(0); //set new group to zero
              c_loss = rr_g;
              continue;
            }else{
              
              //Iterate group updates until convergence
              
              //Inner Loop
              bool c_g_test = true;
              int c_g_counter = 0;
              //arma::vec U_l_old = c(index_g); //Warm start for c_g
              arma::vec U_l_old = arma::zeros(n_g);
              arma::vec c_g_old, U_l;
              int step_counter;
              while(c_g_test==true &&  c_g_counter < max_steps ){
                Rcpp::checkUserInterrupt();
                c_g_counter++;
                c_g_old = c(index_g);
                
                //Define the gradient for group g
                arma::vec grad_min_g = -Vr_g;
                for(int l=0; l<n_g; l++){
                  
                  //Add -V_g^d'(-V_g^d c_g) and divide by t
                  arma::uvec ind_g = I_G[index_g(l)];
                  arma::uvec g_cols_l = gr(ind_g);
                  arma::uvec g_row_l(1); g_row_l.fill(gr(index_g(l)));
                  grad_min_g(l) = (grad_min_g(l) +
                    as_scalar(VV(g_row_l,g_cols_l)*c(ind_g)))/n_y;
                  
                }
                
                //Nesterov updates
                bool step_test = true;
                double v = 1/0.8;
                step_counter = 0;
                while(step_test == true && step_counter < max_steps){
                  step_counter++;
                  v = 0.8*v;
                  arma::vec U_step = c_g_old - v*grad_min_g; //unthresholded update
                  double tmp = 1-v*sqrt(n_g)*lambda_j/sqrt(sum(square(U_step)));
                  double U_multiplier = std::max(0.0,tmp);
                  U_l = U_multiplier*U_step;
                  arma::vec delta_l = U_l - c_g_old;
                  c(index_g) = U_l;
                  
                  //Compute the value of the interim squared loss function
                  cVVc_g = 0;
                  for(int m=0; m<n; m++){
                    arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
                    cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                      VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
                  }
                  double U_loss = rr_g  + (cVVc_g - 2*as_scalar(Vr_g.t()*c(index_g)))/n_total;
                  
                  step_test = U_loss > c_loss + as_scalar(grad_min_g.t()*delta_l)
                    + sum(square(delta_l))/(2*v);
                }
                
                //Update coefficients
                c(index_g) = U_l_old + (U_l-U_l_old)*(c_g_counter/(c_g_counter+3));
                U_l_old = U_l;
                
                //Compute the new value of the squared loss function
                cVVc_g = 0;
                for(int m=0; m<n; m++){
                  arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
                  cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                    VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
                }
                c_loss = rr_g  + (cVVc_g - 2*as_scalar(Vr_g.t()*c(index_g)))/n_total;
                
                //Check for convergence
                if(c_g_counter == 1){
                  c_g_test = true;
                }else if(all(c_g_old==0)){
                  c_g_test = false;
                }else{
                  double c_g_old_norm = sqrt(sum(square(c_g_old)));
                  double c_g_diff = sqrt(sum(square(c(index_g)-c_g_old)))/c_g_old_norm;
                  c_g_test = c_g_diff > thresh;
                }
              } //closes while-loop for c_g
            } //closes if-statement for group update
          } //closes for-loop over groups
          
          //Check for convergence of c
          double c_old_norm = sqrt(sum(square(c_old)));
          if(c_counter==1){
            c_test = true;
          }else if(c_old_norm==0){
            c_test = false;
          }else{
            double tmp = sqrt(sum(square(c-c_old)))/c_old_norm;
            c_test = tmp > thresh;
          }
          
        } //closes while-loop for c
        
        if(track_progress==true){
          Rcout << lambda_counter << " out of " << n_penalties << " done" << std::endl;
        }
        //Store solution for a particular alpha-lambda combination
        int ind_penalty = j + i*n_lambdas;
        c_all.col(ind_penalty) = c;
      } //closes for-loop over lambdas
    } else if(alpha<1){
      
      //Loop over different penalties
      arma::vec c_old;
      
      for(int j=0; j<n_lambdas; j++){
        lambda_counter++;
        
        double lambda_j = lambdas(j);
        double lambda_ind_j = alpha*lambda_j;
        
        //Iterate over the full vector c
        bool c_test = true;
        int c_counter = 0;
        while(c_test==true && c_counter < max_steps){
          Rcpp::checkUserInterrupt();
          
          c_counter++;
          c_old = c;
          
          //Loop over groups in c
          for(unsigned int g : group_seq){
            Rcpp::checkUserInterrupt();
            
            //Define group and coefficients
            arma::uvec index_g = group_indices[g]; //Indices of group g
            int n_g = group_sizes(g); //size of group g
            unsigned int group_g = groups_unique(g);
            double lambda_grp_j = (1-alpha)*sqrt(n_g)*lambda_j;
            
            //Define V_g^d'r_{-g}
            arma::vec Vr_g = zeros(n_g), Vr_g_thresh = zeros(n_g);
            for(int l=0; l<n_g; l++){
              arma::uvec ind_c = I_C[index_g(l)];
              arma::uvec c_cols_l = gr(ind_c);
              arma::uvec c_row_l(1); c_row_l.fill(gr(index_g(l)));
              Vr_g(l) = Sigma1hatV(gc(index_g(l)),gr(index_g(l))) -
                as_scalar(VV(c_row_l,c_cols_l)*c(ind_c));
              Vr_g_thresh(l) = softt(Vr_g(l)/n_y,lambda_ind_j);
            }
            
            //Define r_g'r_g/(2n^2)
            double cVVc_g = 0;
            for(int m=0; m<n; m++){
              arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
              cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
            }
            double rr_g = c_loss + (2*as_scalar(Vr_g.t()*c(index_g)) - cVVc_g)/n_total;
            
            //Check criteria for non-zero group
            if(group_g > max_group){
              
              //Estimate coefficients of exogenous regressors with L1 penalty only
              
              //Inner Loop
              bool c_g_test = true;
              int c_g_counter = 0;
              //arma::vec U_l_old = c(index_g), c_g_old, U_l; //Warm start for c_g
              arma::vec U_l_old = arma::zeros(n_g), c_g_old;
              arma::vec U_l = zeros(n_g);
              int step_counter;
              while(c_g_test==true &&  (c_g_counter < max_steps)){
                Rcpp::checkUserInterrupt();
                c_g_counter++;
                c_g_old = c(index_g);
                
                //Define the gradient for group g
                arma::vec grad_min_g = -Vr_g;
                for(int l=0; l<n_g; l++){
                  //Add -V_g^d'(-V_g^d c_g) and divide by t
                  arma::uvec ind_g = I_G[index_g(l)];
                  arma::uvec g_cols_l = gr(ind_g);
                  arma::uvec g_row_l(1); g_row_l.fill(gr(index_g(l)));
                  grad_min_g(l) = (grad_min_g(l) +
                    as_scalar(VV(g_row_l,g_cols_l)*c(ind_g)))/n_y;
                }
                
                //Nesterov updates
                bool step_test = true;
                double v = 1/0.8;
                step_counter = 0;
                while(step_test == true && step_counter < max_steps){
                  step_counter++;
                  v = 0.8*v;
                  for(int k=0; k<n_g; k++){
                    U_l(k) = softt(c_g_old(k)-v*grad_min_g(k),v*lambda_j);
                  }
                  arma::vec delta_l = U_l - c_g_old;
                  c(index_g) = U_l;
                  
                  //Compute the value of the interim squared loss function
                  cVVc_g = 0;
                  for(int m=0; m<n; m++){
                    arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
                    cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                      VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
                  }
                  double U_loss = rr_g  + (cVVc_g - 2*as_scalar(Vr_g.t()*c(index_g)))/n_total;
                  
                  step_test = U_loss > c_loss + as_scalar(grad_min_g.t()*delta_l)
                    + sum(square(delta_l))/(2*v);
                }
                
                //Update coefficients
                c(index_g) = U_l_old + (U_l-U_l_old)*(c_g_counter/(c_g_counter+3));
                U_l_old = U_l;
                
                //Compute the new value of the squared loss function
                cVVc_g = 0;
                for(int m=0; m<n; m++){
                  arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
                  cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                    VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
                }
                c_loss = rr_g  + (cVVc_g - 2*as_scalar(Vr_g.t()*c(index_g)))/n_total;
                
                //Check for convergence
                if(c_g_counter == 1){
                  c_g_test = true;
                }else if(all(c_g_old==0)){
                  c_g_test = false;
                }else{
                  double c_g_old_norm = sqrt(sum(square(c_g_old)));
                  double c_g_diff = sqrt(sum(square(c(index_g)-c_g_old)))/c_g_old_norm;
                  c_g_test = c_g_diff > thresh;
                }
              } //closes while-loop for c_g
              
            }else if(sqrt(sum(square(Vr_g_thresh))) <= lambda_grp_j){
              c(index_g).fill(0); //set new group to zero
              c_loss = rr_g;
              continue;
              
            }else{
              
              //Iterate group updates until convergence
              
              //Inner Loop
              bool c_g_test = true;
              int c_g_counter = 0;
              //arma::vec U_l_old = c(index_g), c_g_old, U_l; //Warm start for c_g
              arma::vec U_l_old = arma::zeros(n_g), c_g_old, U_l;
              arma::vec U_step = zeros(n_g);
              int step_counter;
              while(c_g_test==true &&  (c_g_counter < max_steps)){
                Rcpp::checkUserInterrupt();
                c_g_counter++;
                c_g_old = c(index_g);
                
                //Define the gradient for group g
                arma::vec grad_min_g = -Vr_g;
                for(int l=0; l<n_g; l++){
                  //Add -V_g^d'(-V_g^d c_g) and divide by t
                  arma::uvec ind_g = I_G[index_g(l)];
                  arma::uvec g_cols_l = gr(ind_g);
                  arma::uvec g_row_l(1); g_row_l.fill(gr(index_g(l)));
                  grad_min_g(l) = (grad_min_g(l) +
                    as_scalar(VV(g_row_l,g_cols_l)*c(ind_g)))/n_y;
                }
                
                //Nesterov updates
                bool step_test = true;
                double v = 1/0.8;
                step_counter = 0;
                while(step_test == true && step_counter < max_steps){
                  step_counter++;
                  v = 0.8*v;
                  for(int k=0; k<n_g; k++){
                    U_step(k) = softt(c_g_old(k)-v*grad_min_g(k),v*lambda_ind_j);
                  }
                  double tmp = 1-v*lambda_grp_j/sqrt(sum(square(U_step)));
                  double U_multiplier = std::max(0.0,tmp);
                  U_l = U_multiplier*U_step;
                  arma::vec delta_l = U_l - c_g_old;
                  c(index_g) = U_l;
                  
                  //Compute the value of the interim squared loss function
                  cVVc_g = 0;
                  for(int m=0; m<n; m++){
                    arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
                    cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                      VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
                  }
                  double U_loss = rr_g  + (cVVc_g - 2*as_scalar(Vr_g.t()*c(index_g)))/n_total;
                  
                  step_test = U_loss > c_loss + as_scalar(grad_min_g.t()*delta_l)
                    + sum(square(delta_l))/(2*v);
                }
                
                //Update coefficients
                c(index_g) = U_l_old + (U_l-U_l_old)*(c_g_counter/(c_g_counter+3));
                U_l_old = U_l;
                
                //Compute the new value of the squared loss function
                cVVc_g = 0;
                for(int m=0; m<n; m++){
                  arma::uvec ind_g_range_m = Rcpp::as<Rcpp::List>(group_partitions[g])[m];
                  cVVc_g = cVVc_g + as_scalar(c(ind_g_range_m).t()*
                    VV.submat(gr(ind_g_range_m),gr(ind_g_range_m))*c(ind_g_range_m));
                }
                c_loss = rr_g  + (cVVc_g - 2*as_scalar(Vr_g.t()*c(index_g)))/n_total;
                
                //Check for convergence
                if(c_g_counter == 1){
                  c_g_test = true;
                }else if(all(c_g_old==0)){
                  c_g_test = false;
                }else{
                  double c_g_old_norm = sqrt(sum(square(c_g_old)));
                  double c_g_diff = sqrt(sum(square(c(index_g)-c_g_old)))/c_g_old_norm;
                  c_g_test = c_g_diff > thresh;
                }
              } //closes while-loop for c_g
            } //closes if-statement for group update
          } //closes for-loop over groups
          
          //Check for convergence of c
          double c_old_norm = sqrt(sum(square(c_old)));
          if(c_counter==1){
            c_test = true;
          }else if(c_old_norm==0){
            c_test = false;
          }else{
            double tmp = sqrt(sum(square(c-c_old)))/c_old_norm;
            c_test = tmp > thresh;
          }
          
        } //closes while-loop for c
        
        if(track_progress==true){
          Rcout << lambda_counter << " out of " << n_penalties << " done" << std::endl;
        }
        //Store solution for a particular alpha-lambda combination
        int ind_penalty = j + i*n_lambdas;
        c_all.col(ind_penalty) = c;
      } //closes for-loop over lambdas
    }else {
      //Estimate the pure lasso
      
      arma::vec c_old =  zeros(n_total), c = zeros(n_total);
      double tmp;
      
      //Update individual coefficients via coordinate descent
      for(int j=0; j<n_lambdas; j++){
        lambda_counter++;
        
        //Iterate coordinate descent algorithm
        bool c_test = true;
        double nsq_lambda_j = n_y*lambdas(j);
        
        int c_counter = 0;
        while(c_test==true && c_counter < max_steps){
          c_counter++;
          c_old = c;
          
          //Loop over individual coefficient
          for(int k : ind_x_incl){
            
            
            //Full pass on first iteration and only non-zeroes thereafter
            if(c_counter==1 || c(k)!=0){
              arma::uvec ind_k = I_ind[k];
              arma::uvec ind_col_k = gr(ind_k);
              arma::uvec ind_row_k(1); ind_row_k.fill(gr(k));
              tmp = Sigma1hatV(gc(k),gr(k)) -
                as_scalar(VV(ind_row_k,ind_col_k)*c(ind_k));
              c(k) = softt(tmp,nsq_lambda_j)/VV(gr(k),gr(k));
            }
          }
          
          //Check for convergence of c
          double c_old_norm = sqrt(sum(square(c_old)));
          if(c_counter==1){
            c_test = true;
          }else if(c_old_norm==0){
            c_test = false;
          }else{
            double tmp = sqrt(sum(square(c-c_old)))/c_old_norm;
            c_test = tmp > thresh;
          }
        } //Closes while loop for c
        
        if(track_progress==true){
          Rcout << lambda_counter << " out of " << n_penalties << " done" << std::endl;
        }
        //Store solution for a particular alpha-lambda combination
        int ind_penalty = j + i*n_lambdas;
        c_all.col(ind_penalty) = c;
      }//Closes for-loop over lambdas
    }//Closes if-statements for alphas
  }//Closes loop over alphas
  
  //Store coefficients in a cube
  arma::cube ABs = cube(n, n_v, n_penalties, fill::zeros);
  for(int i=0; i<n_penalties; i++){
    ABs.slice(i) = reshape(c_all.col(i),n_v,n).t();
  }
  
  //De-standardize if necessary
  if(standardise==true){
    arma::mat sds_inv = diagmat(pow(sds,-1));
    for(int i=0; i<n_penalties; i++){
      ABs.slice(i) = ABs.slice(i)*sds_inv*sd_y;
    }
  }
  
  //Collect output in list
  Rcpp::List ret;
  ret["ABs"] = ABs;
  ret["banded_covs"] = banded_covs;
  ret["lambdas"] = lambdas;
  return ret;
}
