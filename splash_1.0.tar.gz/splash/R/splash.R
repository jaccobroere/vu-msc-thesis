#' SPLASH
#' 
#' 'splash' computes the SPLASH algorithm in Reuvers and Wijlers (2023)
#' 
#' @param Y A (TxN)-dimensional matrix containing the T observations on N spatial units
#' @param X Optional: A (TxNxk)-dimensional array containing T observations for N spatial units of k exogenous variables
#' @param alphas A vector containing the values of alpha that determine the relative penalization of diagonals versus individual parameters. Values closer to zero give more weight to group penalization. Default is c(0,0.5,1).
#' @param lambdas A vector containing the values of the penalty parameter for which the solutions will be calculated. If set to NULL, a sequence containing 'n_lambdas' values will be automatically generated (see next parameter). Default is NULL. 
#' @param n_lambdas If lambdas=NULL, n_lambdas determines the number of values for the penalty parameter will be generated.
#' @param banded_coefs A logical variable indicating whether the coefficient matrices are restricted to being sufficiently banded for identification (see Reuvers and Wijler (2023) for details). Default is TRUE.
#' @param banded_covs A 2-dimensional logical vector. The first (second) element indicates whether Sigma_0 (Sigma_1) should be calculated with a banded estimator. Default is c(FALSE,FALSE).
#' @param B If banded_covs contains a TRUE, the bandwidth for the corresponding banded estimator of Sigma_0 and/or Sigma_1 is calculated based on a bootstrap algorithm with B bootstrap samples. Default is 999.
#' @param standardise A logical variable indicating whether the data in the SPLASH objective function should be standardized prior to estimation, which may improve numerical stability. The returned estimates are always de-standardized. Default is TRUE.
#' @param symmetric_diags A logical variable indicating whether the k-th diagonal above and below the main diagonal should be penalized jointly. Default is TRUE.
#' @param track_progress A logical variable indicating whether a progress report should be printed. Default is TRUE.
#' @param thresh The numerical threshold for convergence. Default is 1e-3.
#' @param max_steps The maximum number of iterations allowed to take to achieve numerical convergence. Default is 1e3.
#' @param lambda_min_mult Only applicable if lambdas=NULL. The multiplier that sets the smallest value of lambda equal to lambda_min_mult*lambda_max. Default is 1e-4
#' 
#' @return A list containing the estimated parameters and, if applicable, the automatically generated sequence of penalties.
#' \item{AB}{An (N x (2+k)N x n_lambdas) array containing the contacenated estimates of A and B, and if X!=NULL also diag(beta_k), for each value of the penalty parameter.}
#' \item{lambdas}{A numerical vector containing the different values for lambdas for which the solutions are calculated.}
#'@export
splash <- function(Y,X=NULL,alphas=seq(0,1,length.out = 3),lambdas=NULL,n_lambdas = 20,
                   banded_coefs=TRUE,banded_covs=c(FALSE,FALSE),B=999,
                   standardise=TRUE,symmetric_diags=TRUE,track_progress = TRUE,
                   thresh = 1e-3, max_steps = 1e3,lambda_min_mult=1e-4){
  
  #Check lambda sequence
  if(is.null(lambdas)){
    lambdas <- -1 #This creates an automated sequence in Rcpp
  }else if(any(lambdas < 0)){
    stop("lambdas cannot contain negative values")
  }else if(!is.numeric(lambdas)){
    stop("lambdas has to be numeric")
  }else{
    n_lambdas = length(lambdas)
  }
  
  #Check for presence of exogenous regressors
  if(is.null(X)){
    X = array(-1,dim=c(1,1,1))
  }
  
  #Redefine banded_covs
  if(banded_covs[1] == TRUE){
    banded_covs[1] <- -1
  }else if(banded_covs[1]==FALSE){
    banded_covs[1] <- 0
  }
  if(banded_covs[2] == TRUE){
    banded_covs[2] <- -1
  }else if(banded_covs[2]==FALSE){
    banded_covs[2] <- 0
  }
  
  #Obtain results
  Rcpp_results <- .splash_rcpp(Y,X,alphas,lambdas,n_lambdas,banded_coefs,
                              banded_covs,B,standardise,symmetric_diags,track_progress,
                              thresh,max_steps,lambda_min_mult)
  AB <- Rcpp_results$ABs
  lambdas <- Rcpp_results$lambdas
  banded_covs <- Rcpp_results$banded_covs
  rownames(banded_covs) <- c("k0","k1")
  
  #output
  list(AB=AB,alphas=alphas,lambdas=lambdas,bandwidth_covs=banded_covs)
}

#' IC_select
#' 
#' The function 'IC_select' computes the optimal solutions based on the AIC and BIC criterion.
#' 
#' @param Y The (TxN)-dimensional matrix containing the T observations on N spatial units.
#' @param X Optional: A (TxNxk)-dimensional array containing T observations for N spatial units of k exogenous variables
#' @param AB The (N x (2+k)N x n_lambdas_dimensional array containing the contacenated estimates of A and B, and if X!=NULL also diag(beta_k), for each value of the penalty parameter.
#' @param alphas The vector containing the values of alpha that were used to calculate the SPLASH solutions.
#' @param lambdas The vector containing the values of the penalty parameter that were used to calculate the SPLASH solutions.
#' @param BIC_local A logical variable indicating whether a local minimum of the BIC should be chosen. Default is TRUE.
#' @param AIC_local A logical variable indicating whether a local minimum of the AIC should be chosen. Default is TRUE.
#' 
#' @return A list containing the optimal estimated parameters the corresponding values for alpha and lambda.
#' \item{AB_opt}{An array containing the optimal contacenated estimates of A and B, and if applicable diag(beta_k), for for each value of the penalty parameter.}
#' \item{penalties_opt}{A matrix containing the optimal values for alpha and lambda, and the order position of lambda within the lambda grid (n_opt).}
#'@export
IC_select <- function(Y,X=NULL,AB,alphas,lambdas,BIC_local=TRUE,AIC_local=TRUE){
  
  #Initialize objects with optimal solutions
  n1 <- dim(AB)[1]; n2 <- dim(AB)[2]
  names <-  paste(rep(c("glas","las","sgl"),each=2),
                  rep(c("BIC","AIC"),3),sep="_")
  AB_opt <- array(0,dim=c(n1,n2,6),
                  dimnames = list(rows=1:n1,cols=1:n2,method=names))
  n_opt <- alpha_opt <- lambda_opt <- rep(0,6)
  names(n_opt) <- names(lambda_opt) <- names
  
  #Organize data
  Y_lead <- Y[-1,]
  Y_lag <- Y[-nrow(Y),]
  if(is.null(X)){
    V <- cbind(Y_lead,Y_lag)
  }else{
    V <- cbind(Y_lead,Y_lag,t(apply(X[-1,,],1,c)))
  }
  t <- nrow(Y_lead)
  n_alphas <- length(alphas)
  n_lambdas <- length(lambdas)
  n_penalties <- n_alphas*n_lambdas #Number of solutions
  lambdas_full <- rep(lambdas,n_alphas)
  
  #Obtain all ICs
  BICs <- AICs <- rep(NA,n_penalties)
  lambdas_BIC_index <- lambdas_AIC_index  <- rep(FALSE,n_penalties)
  n_alphas = length(alphas); n_lambdas = length(lambdas)
  for(i in 1:n_alphas){
    for(j in 1:n_lambdas){
      if(j == 1){
        k_i <- sum(AB[,,(i-1)*n_lambdas + j] != 0)
        lambdas_BIC_index[(i-1)*n_lambdas + j] <- TRUE
        lambdas_AIC_index[(i-1)*n_lambdas + j] <- TRUE
        resids_i <- as.matrix(Y_lead - V%*%t(AB[,,(i-1)*n_lambdas + j]))
        variance_i <- log(det(crossprod(resids_i)/t))
        BICs[(i-1)*n_lambdas + j] <- variance_i + k_i*log(t)/t
        AICs[(i-1)*n_lambdas + j] <- variance_i + 2*k_i/t # + 2*k_i*(k_i+1)/(t-k_i-1)
      }else{
        k_i <- sum(AB[,,(i-1)*n_lambdas + j] != 0)
        lambdas_BIC_index[(i-1)*n_lambdas + j] <- TRUE
        lambdas_AIC_index[(i-1)*n_lambdas + j] <- TRUE
        resids_i <- as.matrix(Y_lead - V%*%t(AB[,,(i-1)*n_lambdas + j]))
        variance_i <- log(det(crossprod(resids_i)/t))
        BICs[(i-1)*n_lambdas + j] <- variance_i + k_i*log(t)/t
        AICs[(i-1)*n_lambdas + j] <- variance_i + 2*k_i/t # + 2*k_i*(k_i+1)/(t-k_i-1)
      }
    }
  }
  
  #Select (local) BIC minimum
  n_BIC_opt <- rep(NA,length(alphas))
  if(BIC_local){
    for(i in 1:n_alphas){
      cond_BIC <- TRUE
      for(j in 2:length(lambdas)){
        
        #Select local BIC
        if(cond_BIC){
          if(j < length(lambdas)){
            if(BICs[(i-1)*n_lambdas + j-1] > BICs[(i-1)*n_lambdas + j] &
               BICs[(i-1)*n_lambdas + j+1] > BICs[(i-1)*n_lambdas + j]){
              n_BIC_opt[i] <- (i-1)*n_lambdas + j
              cond_BIC <- FALSE
            }
          }else{
            n_BIC_opt[i] <- (i-1)*n_lambdas + j
          }
        }
        
        #Break if AIC and BIC reached the local minimum
        if(!cond_BIC){
          break
        }
      }
    }
  }else{
    for(i in 1:n_alphas){
      index <- ((i-1)*n_lambdas + 1):(i*n_lambdas)
      n_BIC_opt[i] <- which.min(BICs[index]) + (i-1)*n_lambdas
    }
  }
  
  #Select (local) AIC minimum
  n_AIC_opt <- rep(NA,length(alphas))
  if(AIC_local){
    for(i in 1:n_alphas){
      cond_AIC <- TRUE
      for(j in 2:length(lambdas)){
        
        #Select local AIC
        if(cond_AIC){
          if(j < length(lambdas)){
            if(AICs[(i-1)*n_lambdas + j-1] > AICs[(i-1)*n_lambdas + j] &
               AICs[(i-1)*n_lambdas + j+1] > AICs[(i-1)*n_lambdas + j]){
              n_AIC_opt[i] <- (i-1)*n_lambdas + j
              cond_AIC <- FALSE
            }
          }else{
            n_AIC_opt[i] <- (i-1)*n_lambdas + j
          }
          
        }
        
        #Break if AIC and BIC reached the local minimum
        if(!cond_AIC){
          break
        }
      }
    }
  }else{
    for(i in 1:n_alphas){
      index <- ((i-1)*n_lambdas + 1):(i*n_lambdas)
      n_AIC_opt[i] <- which.min(AICs[index]) + (i-1)*n_lambdas
    }
  }
  
  #Obtain group lasso solution
  if(0 %in% alphas){
    
    #group lasso indices
    alpha_ind <- which(alphas == 0)
    
    #Obtain optimal BIC
    n_IC_opt <-  n_BIC_opt[alpha_ind]
    lambda_IC_opt <- lambdas_full[n_IC_opt]
    alpha_IC_opt <- alphas[ceiling(n_IC_opt/length(lambdas))]
    alpha_opt[1] <- alpha_IC_opt
    lambda_opt[1] <- lambda_IC_opt
    n_opt[1] <- n_IC_opt
    AB_opt[,,"glas_BIC"] <- AB[,,n_IC_opt]
    
    #Obtain optimal AIC
    n_IC_opt <-  n_AIC_opt[alpha_ind]
    lambda_IC_opt <- lambdas_full[n_IC_opt]
    alpha_IC_opt <- alphas[ceiling(n_IC_opt/length(lambdas))]
    alpha_opt[2] <- alpha_IC_opt
    lambda_opt[2] <- lambda_IC_opt
    n_opt[2] <- n_IC_opt
    AB_opt[,,"glas_AIC"] <- AB[,,n_IC_opt]
  }else{
    AB_opt[,,c("glas_BIC","glas_AIC")] <- NULL
  }
  
  #Obtain lasso solution
  if(1 %in% alphas){
    
    #group lasso indices
    alpha_ind <- which(alphas == 1)
    
    #Obtain optimal BIC
    n_IC_opt <-  n_BIC_opt[alpha_ind]
    lambda_IC_opt <- lambdas_full[n_IC_opt]
    alpha_IC_opt <- alphas[ceiling(n_IC_opt/length(lambdas))]
    alpha_opt[3] <- alpha_IC_opt
    lambda_opt[3] <- lambda_IC_opt
    n_opt[3] <- n_IC_opt
    AB_opt[,,"las_BIC"] <- AB[,,n_IC_opt]
    
    #Obtain optimal AIC
    n_IC_opt <-  n_AIC_opt[alpha_ind]
    lambda_IC_opt <- lambdas_full[n_IC_opt]
    alpha_IC_opt <- alphas[ceiling(n_IC_opt/length(lambdas))]
    alpha_opt[4] <- alpha_IC_opt
    lambda_opt[4] <- lambda_IC_opt
    n_opt[4] <- n_IC_opt
    AB_opt[,,"las_AIC"] <- AB[,,n_IC_opt]
  }else{
    AB_opt[,,"las_BIC"] <- NULL
    AB_opt[,,"las_AIC"] <- NULL
  }
  
  #Obtain sparse group lasso solution
  
  #Obtain optimal BIC
  n_IC_opt <-  n_BIC_opt[which.min(BICs[n_BIC_opt])]
  lambda_IC_opt <- lambdas_full[n_IC_opt]
  alpha_IC_opt <- alphas[ceiling(n_IC_opt/length(lambdas))]
  alpha_opt[5] <- alpha_IC_opt
  lambda_opt[5] <- lambda_IC_opt
  n_opt[5] <- n_IC_opt
  AB_opt[,,"sgl_BIC"] <- AB[,,n_IC_opt]
  
  #Obtain optimal AIC
  n_IC_opt <-  n_AIC_opt[which.min(AICs[n_AIC_opt])]
  lambda_IC_opt <- lambdas_full[n_IC_opt]
  alpha_IC_opt <- alphas[ceiling(n_IC_opt/length(lambdas))]
  alpha_opt[6] <- alpha_IC_opt
  lambda_opt[6] <- lambda_IC_opt
  n_opt[6] <- n_IC_opt
  AB_opt[,,"sgl_AIC"] <- AB[,,n_IC_opt]
  
  #Output
  penalties_opt <- rbind(alpha_opt,lambda_opt,n_opt)
  rownames(penalties_opt) <- c("alpha","lambda","n_penalty")
  list(AB_opt=AB_opt,penalties_opt=penalties_opt)
}

#' Time Series Cross-validation
#' 
#' The function CV_select computes the optimal solution to SPLASH based on time series cross-validation.
#' 
#' @param Y A (TxN)-dimensional matrix containing the T observations on N spatial units
#' @param X Optional: A (TxNxk)-dimensional array containing T observations for N spatial units of k exogenous variables
#' @param alphas A vector containing the values of alpha that determine the relative penalization of diagonals versus individual parameters. Values closer to zero give more weight to group penalization. Default is c(0,0.5,1).
#' @param lambdas A vector containing the values of the penalty parameter for which the solutions will be calculated. If set to NULL, a sequence containing 'n_lambdas' values will be automatically generated (see next parameter). Default is NULL. 
#' @param n_lambdas If lambdas=NULL, n_lambdas determines the number of values for the penalty parameter will be generated.
#' @param banded_coefs A logical variable indicating whether the coefficient matrices are restricted to being sufficiently banded for identification (see Reuvers and Wijler (2023) for details). Default is TRUE.
#' @param banded_covs A 2-dimensional logical vector. The first (second) element indicates whether Sigma_0 (Sigma_1) should be calculated with a banded estimator. Default is c(FALSE,FALSE).
#' @param B If banded_covs contains a TRUE, the bandwidth for the corresponding banded estimator of Sigma_0 and/or Sigma_1 is calculated based on a bootstrap algorithm with B bootstrap samples. Default is 999.
#' @param standardise A logical variable indicating whether the data in the SPLASH objective function should be standardized prior to estimation, which may improve numerical stability. The returned estimates are always de-standardized. Default is TRUE.
#' @param symmetric_diags A logical variable indicating whether the k-th diagonal above and below the main diagonal should be penalized jointly. Default is TRUE.
#' @param track_progress A logical variable indicating whether a progress report should be printed. Default is TRUE.
#' @param thresh The numerical threshold for convergence. Default is 1e-3.
#' @param max_steps The maximum number of iterations allowed to take to achieve numerical convergence. Default is 1e3.
#' @param lambda_min_mult Only applicable if lambdas=NULL. The multiplier that sets the smallest value of lambda equal to lambda_min_mult*lambda_max. Default is 1e-4.
#' @param CV_cutoff A numeric value between 0 and 1 indicating the percentage of the training sample. Default is 0.8.
#' @param RF A logical variable indicated whether the MSFE should be calculated based on the reduced form specification. Default is FALSE.
#' @param ME A logical variable indicating whether a comparison should be made based on the MSE of the estimated coefficients. This requires the true coefficients and is only relevant in simulated designs. Default is FALSE.
#' @param AB_true A matrix containing the true parameters. Only relevant in simulated settings and for ME=TRUE. Default is NULL.
#' 
#' @return A list containing the optimal estimated parameters the corresponding values for alpha and lambda.
#' \item{AB_opt}{An array containing the optimal contacenated estimates of A and B, and if applicable diag(beta_k), for for each value of the penalty parameter.}
#' \item{penalties_opt}{A matrix containing the optimal values for alpha and lambda, and the order position of lambda within the lambda grid (n_opt).}
#' \item{bandwidth_covs}{Only relevant when banded_covs contains a true. In that case, this contains the bandwidth(s) chosen via a bootstrap algorithm.}
#'@export
CV_select <- function(Y,X=NULL,alphas=seq(0,1,length.out = 3),lambdas=NULL,n_lambdas = 20,
                      banded_coefs=TRUE,banded_covs=c(FALSE,FALSE),B=1000,
                      standardise=TRUE,symmetric_diags=TRUE,track_progress = TRUE,
                      thresh = 1e-3, max_steps = 1e3,lambda_min_mult=1e-4,
                      CV_cutoff=0.8,RF=FALSE,ME=FALSE,AB_true=NULL){
  
  #Initialize objects with optimal solutions
  n <- ncol(Y); n2 <- 2*n;
  k_x <- ifelse(is.null(X),0,dim(X)[3])
  n_total <- (2+k_x)*n
  if(k_x>0 & RF==TRUE){
    stop("Cannot compute reduced form forecasts with exogenous variables included.")
  }
  
  names <- paste(c("glas","las","sgl"),"min_SVAR",sep="_")
  if(RF==TRUE){
    names <- c(names,paste(c("glas","las","sgl"),"min_RF",sep="_"))
  }
  if(ME==TRUE){
    names <- c(names,paste(names,"_ME",sep=""))
  }
  n_methods <- length(names)
  AB_opt <- array(NA,dim=c(n,n_total,n_methods),
                  dimnames = list(rows=1:n,cols=1:n_total,method=names))
  n_opt <- alpha_opt <- lambda_opt <- rep(0,n_methods)
  names(n_opt) <- names(alpha_opt) <- names(lambda_opt) <- names
  eye <- diag(n)
  
  #Define train and test sample
  t_train <- floor(nrow(Y)*CV_cutoff)
  Y_train <- Y[1:t_train,]
  Y_test <- Y[(t_train+2):nrow(Y),]
  if(k_x>0){
    X_train <- X[1:t_train,,,drop=FALSE]
    X_test <- t(apply(X[(t_train+2):nrow(Y),,],1,c)) #horizontal concatenation
  }else{
    X_train <- X_test <- NULL
  }
  
  #Obtain estimates on training sample
  if(!is.null(lambdas)){
    n_lambdas <- length(lambdas)
  }
  training_fit <- splash(Y_train,X_train,alphas,lambdas,n_lambdas,banded_coefs,banded_covs,B,
                         standardise,symmetric_diags,track_progress,
                         thresh,max_steps,lambda_min_mult)
  AB_train <- training_fit$AB
  lambdas <- training_fit$lambdas
  alphas <- training_fit$alphas
  banded_covs <- c(training_fit$banded_covs)
  n_alphas <- length(alphas)
  n_lambdas <- length(lambdas)
  n_penalties <- n_alphas*n_lambdas
  lambdas_full <- rep(lambdas,length(alphas))
  
  #Get optimal solutions for SVAR
  V_test <- cbind(Y_test,Y[(t_train+1):(nrow(Y)-1),],X_test)
  
  #Obtain sfes
  sfes <- rep(0,n_penalties)
  for(i in 1:n_penalties){
    resids_i <- Y_test - V_test%*%t(AB_train[,,i])
    sfes[i] <- Matrix::norm(resids_i,"F")
  }
  
  if(ME==TRUE){
    sfes_ME <- rep(0,n_penalties)
    for(i in 1:n_penalties){
      resids_i <- V_test%*%t(AB_true - AB_train[,,i])
      sfes_ME[i] <- Matrix::norm(resids_i,"F")
    }
  }
  
  #Obtain group lasso solution
  if(0 %in% alphas){
    
    #group lasso indices
    alpha_ind <- which(alphas == 0)
    n_index <- ((alpha_ind-1)*n_lambdas+1):(alpha_ind*n_lambdas)
    CV_sfes <- sfes[n_index]
    
    #Provide solution for lambda.min
    n_min_opt <- n_index[which.min(CV_sfes)]
    lambda_min <- lambdas_full[n_min_opt]
    alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
    fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                      standardise,symmetric_diags,track_progress=F,
                      thresh,max_steps,lambda_min_mult)
    AB_min <- fit_min$AB[,,1]
    alpha_opt["glas_min_SVAR"] <- alpha_min
    lambda_opt["glas_min_SVAR"] <- lambda_min
    n_opt["glas_min_SVAR"] <- n_min_opt
    AB_opt[,,"glas_min_SVAR"] <- AB_min
  }
  
  #Obtain lasso solution
  if(1 %in% alphas){
    
    #lasso indices
    alpha_ind <- which(alphas == 1)
    n_index <- ((alpha_ind-1)*n_lambdas+1):(alpha_ind*n_lambdas)
    CV_sfes <- sfes[n_index]
    
    #Provide solution for lambda.min
    n_min_opt <- n_index[which.min(CV_sfes)]
    lambda_min <- lambdas_full[n_min_opt]
    alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
    fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                      standardise,symmetric_diags,track_progress=F,
                      thresh,max_steps,lambda_min_mult)
    AB_min <- fit_min$AB[,,1]
    alpha_opt["las_min_SVAR"] <- alpha_min
    lambda_opt["las_min_SVAR"] <- lambda_min
    n_opt["las_min_SVAR"] <- n_min_opt
    AB_opt[,,"las_min_SVAR"] <- AB_min
  }
  
  #Obtain sparse group lasso solution
  
  #Provide solution for lambda.min
  n_min_opt <- which.min(sfes)
  lambda_min <- lambdas_full[n_min_opt]
  alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
  fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                    standardise,symmetric_diags,track_progress=F,
                    thresh,max_steps,lambda_min_mult)
  AB_min <- fit_min$AB[,,1]
  alpha_opt["sgl_min_SVAR"] <- alpha_min
  lambda_opt["sgl_min_SVAR"] <- lambda_min
  n_opt["sgl_min_SVAR"] <- n_min_opt
  AB_opt[,,"sgl_min_SVAR"] <- AB_min
  
  if(ME==TRUE){
    
    #Obtain group lasso solution
    if(0 %in% alphas){
      
      #group lasso indices
      alpha_ind <- which(alphas == 0)
      n_index <- ((alpha_ind-1)*n_lambdas+1):(alpha_ind*n_lambdas)
      CV_sfes <- sfes_ME[n_index]
      
      #Provide solution for lambda.min
      n_min_opt <- n_index[which.min(CV_sfes)]
      lambda_min <- lambdas_full[n_min_opt]
      alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
      fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                        standardise,symmetric_diags,track_progress=F,
                        thresh,max_steps,lambda_min_mult)
      AB_min <- fit_min$AB[,,1]
      alpha_opt["glas_min_SVAR_ME"] <- alpha_min
      lambda_opt["glas_min_SVAR_ME"] <- lambda_min
      n_opt["glas_min_SVAR_ME"] <- n_min_opt
      AB_opt[,,"glas_min_SVAR_ME"] <- AB_min
    }
    
    #Obtain lasso solution
    if(1 %in% alphas){
      
      #lasso indices
      alpha_ind <- which(alphas == 1)
      n_index <- ((alpha_ind-1)*n_lambdas+1):(alpha_ind*n_lambdas)
      CV_sfes <- sfes_ME[n_index]
      
      #Provide solution for lambda.min
      n_min_opt <- n_index[which.min(CV_sfes)]
      lambda_min <- lambdas_full[n_min_opt]
      alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
      fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                        standardise,symmetric_diags,track_progress=F,
                        thresh,max_steps,lambda_min_mult)
      AB_min <- fit_min$AB[,,1]
      alpha_opt["las_min_SVAR_ME"] <- alpha_min
      lambda_opt["las_min_SVAR_ME"] <- lambda_min
      n_opt["las_min_SVAR_ME"] <- n_min_opt
      AB_opt[,,"las_min_SVAR_ME"] <- AB_min
    }
    
    #Obtain sparse group lasso solution
    
    #Provide solution for lambda.min
    n_min_opt <- which.min(sfes_ME)
    lambda_min <- lambdas_full[n_min_opt]
    alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
    fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                      standardise,symmetric_diags,track_progress=F,
                      thresh,max_steps,lambda_min_mult)
    AB_min <- fit_min$AB[,,1]
    alpha_opt["sgl_min_SVAR_ME"] <- alpha_min
    lambda_opt["sgl_min_SVAR_ME"] <- lambda_min
    n_opt["sgl_min_SVAR_ME"] <- n_min_opt
    AB_opt[,,"sgl_min_SVAR_ME"] <- AB_min
  }
  
  #Get optimal solutions for RF
  if(RF==TRUE){
    V_test <- Y[(t_train+1):(nrow(Y)-1),]
    
    #Obtain sfes
    sfes <- rep(0,n_penalties)
    for(i in 1:n_penalties){
      C_train_i <- solve(eye-AB_train[,1:n,i],AB_train[,(n+1):n2,i])
      resids_i <- Y_test - V_test%*%t(C_train_i)
      sfes[i] <- Matrix::norm(resids_i,"F")
    }
    
    if(ME==TRUE){
      sfes_ME <- rep(0,n_penalties)
      C_true <- solve(eye-AB_true[,1:n],AB_true[,(n+1):n2])
      for(i in 1:n_penalties){
        C_train_i <- solve(eye-AB_train[,1:n,i],AB_train[,(n+1):n2,i])
        resids_i <- V_test%*%t(C_true - C_train_i)
        sfes_ME[i] <- Matrix::norm(resids_i,"F")
      }
    }
    
    #Obtain group lasso solution
    if(0 %in% alphas){
      
      #group lasso indices
      alpha_ind <- which(alphas == 0)
      n_index <- ((alpha_ind-1)*n_lambdas+1):(alpha_ind*n_lambdas)
      CV_sfes <- sfes[n_index]
      
      #Provide solution for lambda.min
      n_min_opt <- n_index[which.min(CV_sfes)]
      lambda_min <- lambdas_full[n_min_opt]
      alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
      fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                        standardise,symmetric_diags,track_progress=F,
                        thresh,max_steps,lambda_min_mult)
      AB_min <- fit_min$AB[,,1]
      alpha_opt["glas_min_RF"] <- alpha_min
      lambda_opt["glas_min_RF"] <- lambda_min
      n_opt["glas_min_RF"] <- n_min_opt
      AB_opt[,,"glas_min_RF"] <- AB_min
    }
    
    #Obtain lasso solution
    if(1 %in% alphas){
      
      #lasso indices
      alpha_ind <- which(alphas == 1)
      n_index <- ((alpha_ind-1)*n_lambdas+1):(alpha_ind*n_lambdas)
      CV_sfes <- sfes[n_index]
      
      #Provide solution for lambda.min
      n_min_opt <- n_index[which.min(CV_sfes)]
      lambda_min <- lambdas_full[n_min_opt]
      alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
      fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                        standardise,symmetric_diags,track_progress=F,
                        thresh,max_steps,lambda_min_mult)
      AB_min <- fit_min$AB[,,1]
      alpha_opt["las_min_RF"] <- alpha_min
      lambda_opt["las_min_RF"] <- lambda_min
      n_opt["las_min_RF"] <- n_min_opt
      AB_opt[,,"las_min_RF"] <- AB_min
    }
    
    #Obtain sparse group lasso solution
    
    #Provide solution for lambda.min
    n_min_opt <- which.min(sfes)
    lambda_min <- lambdas_full[n_min_opt]
    alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
    fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                      standardise,symmetric_diags,track_progress=F,
                      thresh,max_steps,lambda_min_mult)
    AB_min <- fit_min$AB[,,1]
    alpha_opt["sgl_min_RF"] <- alpha_min
    lambda_opt["sgl_min_RF"] <- lambda_min
    n_opt["sgl_min_RF"] <- n_min_opt
    AB_opt[,,"sgl_min_RF"] <- AB_min
    
    if(ME==TRUE){
      
      #Obtain group lasso solution
      if(0 %in% alphas){
        
        #group lasso indices
        alpha_ind <- which(alphas == 0)
        n_index <- ((alpha_ind-1)*n_lambdas+1):(alpha_ind*n_lambdas)
        CV_sfes <- sfes_ME[n_index]
        
        #Provide solution for lambda.min
        n_min_opt <- n_index[which.min(CV_sfes)]
        lambda_min <- lambdas_full[n_min_opt]
        alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
        fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                          standardise,symmetric_diags,track_progress=F,
                          thresh,max_steps,lambda_min_mult)
        AB_min <- fit_min$AB[,,1]
        alpha_opt["glas_min_RF_ME"] <- alpha_min
        lambda_opt["glas_min_RF_ME"] <- lambda_min
        n_opt["glas_min_RF_ME"] <- n_min_opt
        AB_opt[,,"glas_min_RF_ME"] <- AB_min
      }
      
      #Obtain lasso solution
      if(1 %in% alphas){
        
        #lasso indices
        alpha_ind <- which(alphas == 1)
        n_index <- ((alpha_ind-1)*n_lambdas+1):(alpha_ind*n_lambdas)
        CV_sfes <- sfes_ME[n_index]
        
        #Provide solution for lambda.min
        n_min_opt <- n_index[which.min(CV_sfes)]
        lambda_min <- lambdas_full[n_min_opt]
        alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
        fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                          standardise,symmetric_diags,track_progress=F,
                          thresh,max_steps,lambda_min_mult)
        AB_min <- fit_min$AB[,,1]
        alpha_opt["las_min_RF_ME"] <- alpha_min
        lambda_opt["las_min_RF_ME"] <- lambda_min
        n_opt["las_min_RF_ME"] <- n_min_opt
        AB_opt[,,"las_min_RF_ME"] <- AB_min
      }
      
      #Obtain sparse group lasso solution
      
      #Provide solution for lambda.min
      n_min_opt <- which.min(sfes_ME)
      lambda_min <- lambdas_full[n_min_opt]
      alpha_min <- alphas[ceiling(n_min_opt/n_lambdas)]
      fit_min <- splash(Y,X,alpha_min,lambda_min,1,banded_coefs,banded_covs,B,
                        standardise,symmetric_diags,track_progress=F,
                        thresh,max_steps,lambda_min_mult)
      AB_min <- fit_min$AB[,,1]
      alpha_opt["sgl_min_RF_ME"] <- alpha_min
      lambda_opt["sgl_min_RF_ME"] <- lambda_min
      n_opt["sgl_min_RF_ME"] <- n_min_opt
      AB_opt[,,"sgl_min_RF_ME"] <- AB_min
    }
  }
  
  #output
  penalties_opt <- rbind(alpha_opt,lambda_opt,n_opt)
  rownames(penalties_opt) <- c("alpha","lambda","n_penalty")
  list(AB_opt=AB_opt,penalties_opt=penalties_opt,bandwidth_covs=banded_covs)
}